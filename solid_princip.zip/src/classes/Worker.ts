import Human from "./Human";

class TWorker extends Human {
    
  constructor(
    name: string,
    lastName: string,
    age: number,
    domaine: string,
    style: string,
  ) {
    super();
    this.setName(name);
    this.setLastName(lastName);
    this.setAge(age);
    this.setStyle(style);
    this.setFonction(domaine);
  }
  fullName(): string {
      return this.getName() + " " + this.getLastName();
  }
}
export default TWorker;
