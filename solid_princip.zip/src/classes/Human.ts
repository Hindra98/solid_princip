abstract class Human {
  abstract fullName(): string;

  private id: number = 0;
  private name: string = "";
  private lastName: string = "";
  private age: number = 0;
  private style: string = "";
  private fonction: string = "";

  public getId(): number {
    return this.id;
  }
  public setId(id: number) {
    this.id = id;
  }
  public getName(): string {
    return this.name;
  }
  public setName(name: string) {
    this.name = name;
  }

  public getLastName(): string {
    return this.lastName;
  }
  public setLastName(lastName: string) {
    this.lastName = lastName;
  }

  public getAge(): number {
    return this.age;
  }
  public setAge(age: number) {
    this.age = age;
  }

  public getFonction(): string {
    return this.fonction;
  }
  public setFonction(fonction: string) {
    this.fonction = fonction;
  }

  public getStyle(): string {
    return this.style;
  }
  public setStyle(style: string) {
    this.style = style;
  }
}

export default Human;
