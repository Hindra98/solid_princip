import Human from "./Human";

class Eleve extends Human {
    points:number = 0;
    
  constructor(
    id: number,
    name: string,
    lastName: string,
    age: number,
    classe: string,
    points: number,
    style: string = "bg-red-400 font-bold",
  ) {
    super();
    this.setId(id);
    this.setName(name);
    this.setLastName(lastName);
    this.setAge(age);
    this.setStyle(style);
    this.setFonction(classe);
    this.points = points;
  }
  fullName(): string {
      return this.getName() + " " + this.getLastName();
  }
}
export default Eleve;
