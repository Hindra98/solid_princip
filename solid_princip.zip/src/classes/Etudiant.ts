import Human from './Human'

class Etudiant extends Human {
    
    constructor(
      name: string,
      lastName: string,
      age: number,
      filiere: string,
      style: string,
    ) {
      super();
      this.setName(name);
      this.setLastName(lastName);
      this.setAge(age);
      this.setStyle(style);
      this.setFonction(filiere);
    }
    fullName(): string {
        return this.getName() + " " + this.getLastName();
    }
}

export default Etudiant