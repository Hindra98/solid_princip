interface WelcomeMessage {
  /**
   * function to be called when fullName
   */
  fullName(): void;
}
export default WelcomeMessage;