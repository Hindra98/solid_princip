import oneHuman from "./DTO/OneHuman";

interface AllTypeHumanInterface {
    allEleves: oneHuman[];
    getAllEleves(): oneHuman[];
}

export default AllTypeHumanInterface;