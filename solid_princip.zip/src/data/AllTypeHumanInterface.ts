import oneHuman from "./DTO/OneHuman";

interface AllTypeHumanInterface {
    allHuman: oneHuman[];
    getAllEleve(): oneHuman[];
    getAllEleve(): oneHuman[];
    getAllEtudiant(): oneHuman[];
    getAllWorker(): oneHuman[];
}

export default AllTypeHumanInterface;