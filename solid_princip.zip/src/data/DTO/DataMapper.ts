import Eleve from "../../classes/Eleve";
// import TWorker from "../../classes/Worker";
import OneHuman from "./OneHuman";

export default class DataMapper {
    mapEleveToOneHuman(eleve: Eleve): OneHuman {
      return new OneHuman(
        eleve.getId(),
          eleve.getName() + " " +eleve.getLastName(),
          eleve.getAge(),
          eleve.getFonction(),
          eleve.points,
        eleve.getStyle()
      );
    }
    // mapWorkerToOneHuman(worker: TWorker): OneHuman {
    //   return new OneHuman(
    //       worker.getName + worker.getLastName(),
    //       worker.getAge(),
    //       worker.getFonction(),
    //       5,
    //     worker.getStyle()
    //   );
    // }
}
