interface OneTypeHumanInterface {
    id: number;
    fullName: string;
    age: number;
    fonction: string;
    points: number;
    style: string;
}

export default OneTypeHumanInterface;