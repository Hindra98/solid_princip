import { createSlice } from "@reduxjs/toolkit";
import type { RootState } from "./store/store";
import GetElevesService from "./data/AllEleves";

// Define the initial state using that type
const allEleves = new GetElevesService().getAllEleves(); // Type OneHuman[]

const initialStates = {
  value: allEleves,
};

// const initialStates = () => {
//   const test: [
//     {
//       id: number;
//       fullName: string;
//       age: number;
//       fonction: string;
//       points: number;
//       style: string;
//     }
//   ] = [
//     {
//       id: 1,
//       fullName: allEleves[0].getOneTypeHuman().fullName,
//       age: allEleves[0].getOneTypeHuman().age,
//       fonction: allEleves[0].getOneTypeHuman().fonction,
//       points: allEleves[0].getOneTypeHuman().points,
//       style: allEleves[0].getOneTypeHuman().style,
//     },
//   ];

//   allEleves.map((eleve, key) => {
//     key > 0 &&
//     test.push({
//       id: eleve.getOneTypeHuman().id,
//       fullName: eleve.getOneTypeHuman().fullName,
//       age: eleve.getOneTypeHuman().age,
//       fonction: eleve.getOneTypeHuman().fonction,
//       points: eleve.getOneTypeHuman().points,
//       style: eleve.getOneTypeHuman().style,
//     });
//   });

//   return test;
// };

export const eleveSlice = createSlice({
  name: "eleve",
  // `createSlice` will infer the state type from the `initialState` argument

  initialState: initialStates,
  reducers: {
    increment: (state, action: { payload: { id: number } }) => {
        //   state.map((eleve) => eleve.id == action.payload.id && eleve.points++);
        
        state.value.map((eleve) => eleve.id == action.payload.id && eleve.points++);

    },
    decrement: (state, action: { payload: { id: number } }) => {
        //   state.map((eleve) => eleve.id == action.payload.id && eleve.points--);

      state.value.map((eleve) => eleve.id == action.payload.id && eleve.points--);

    },
    // Use the PayloadAction type to declare the contents of `action.payload`
    incrementByAmount: (
      state,
      action: { payload: { id: number; points: number } }
    ) => {
      const stateE = state.value[action.payload.id];
      stateE.points += action.payload.points;
      state.value.splice(action.payload.id, 1, stateE);

        // const stateE = state.value[action.payload.id];
        // state.value.map(
        //   (eleve) =>
        //     eleve.getOneTypeHuman().id == action.payload.id &&
        //     eleve.setOneTypeHuman({
        //       fullName: stateE.getOneTypeHuman().fullName,
        //       age: stateE.getOneTypeHuman().age,
        //       fonction: stateE.getOneTypeHuman().fonction,
        //       points: stateE.getOneTypeHuman().points + action.payload.points,
        //     })
        // );
    },
    // Use the PayloadAction type to declare the contents of `action.payload`
    remplir: (state) => {
      state;
    },
    // Use the PayloadAction type to declare the contents of `action.payload`
    initial: (state) => {
      state;
    },
  },
});

export const { increment, decrement, incrementByAmount, initial, remplir } =
  eleveSlice.actions;

// Other code such as selectors can use the imported `RootState` type
export const selectAllEleves = (state: RootState) => state;

const com = eleveSlice.reducer;
export default com;
