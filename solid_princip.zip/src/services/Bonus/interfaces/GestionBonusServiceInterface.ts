

interface gestionBonusServiceInterface{
  points: number;
  addBonus(id: number):void;
  removeBonus(id: number): void;
}

export default gestionBonusServiceInterface;