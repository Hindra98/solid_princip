

interface gestionBonusServiceInterface{
  points: number;
  addBonus(p: number):void;
  removeBonus(p: number): void;
}

export default gestionBonusServiceInterface;