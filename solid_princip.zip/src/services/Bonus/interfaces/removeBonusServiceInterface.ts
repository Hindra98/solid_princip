
interface removeBonusServiceInterface {
  removeBonus(id: number): void;
}

export default removeBonusServiceInterface;