
interface removeBonusServiceInterface {
  removeBonus(p: number): void;
}

export default removeBonusServiceInterface;