
interface addBonusServiceInterface {
  addBonus(id: number): void;
}

export default addBonusServiceInterface;