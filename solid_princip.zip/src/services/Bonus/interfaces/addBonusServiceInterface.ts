
interface addBonusServiceInterface {
  addBonus(p: number): void;
}

export default addBonusServiceInterface;