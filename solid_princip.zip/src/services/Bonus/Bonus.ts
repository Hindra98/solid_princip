import addBonusServiceInterface from "./interfaces/addBonusServiceInterface";
import removeBonusServiceInterface from "./interfaces/removeBonusServiceInterface";

abstract class Bonus implements addBonusServiceInterface, removeBonusServiceInterface {
    bonus1 : number = 5;
    bonus2 : number = 10;
    bonus3 : number = 20;
    addBonus(p: number): void {
        this.bonus1 = p;
    }
    removeBonus(p: number): void {
        this.bonus1 = p;
    }
}

export default Bonus;